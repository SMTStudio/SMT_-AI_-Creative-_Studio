# SMT — Phone-only GitHub Build

این پروژه برای ساخت APK با GitHub Actions آماده شده است.

## مهم
فایل ZIP را داخل GitHub به‌صورت یک فایل ZIP آپلود نکنید؛ ابتدا ZIP را روی گوشی Extract کنید و **محتویات داخل آن** را در ریشه Repository آپلود کنید.

ساختار ریشه باید شامل این موارد باشد:
- `.github/workflows/build-apk.yml`
- `app/`
- `gradle/`
- `build.gradle.kts`
- `settings.gradle.kts`
- `gradle.properties`

بعد از Commit، از تب Actions اجرای `SMT Android APK` را باز کنید. Workflow APK را می‌سازد و به‌عنوان Artifact با نام `SMT-1.0.0-APK` قرار می‌دهد.
