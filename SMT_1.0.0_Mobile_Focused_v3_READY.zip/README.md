# SMT 1.0.0 — Mobile Focused Foundation

این نسخه برای اجرای SMT روی گوشی Android طراحی شده است.

## مشخصات
- minSdk 26
- compileSdk 36
- targetSdk 36
- Kotlin + Jetpack Compose + Material 3
- RTL فارسی
- کادر‌بندی واکنش‌گرا برای گوشی‌های باریک و معمولی
- رعایت status/navigation bars و keyboard insets

## اجرای پروژه
1. Android Studio را نصب کنید.
2. این پوشه را با Open باز کنید.
3. SDK Platform 36 و Build Tools لازم را نصب کنید.
4. Gradle Sync را اجرا کنید.
5. یک گوشی Android یا Emulator انتخاب کنید.
6. Run را بزنید.

> این محیط APK را Build نکرده است، چون Android SDK/Gradle distribution در محیط ساخت حاضر موجود نیست. قبل از ادعای Release باید روی Android Studio و دستگاه واقعی Build/Test شود.

## تست استاتیک موبایل
```bash
python tools/mobile_static_test.py
```
