from pathlib import Path
import re, sys
root=Path(__file__).resolve().parents[1]
src=(root/'app/src/main/java/com/smt/creative/ui/SmtApp.kt').read_text()
gradle=(root/'app/build.gradle.kts').read_text()
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
checks={
 'minSdk 26':'minSdk = 26' in gradle,
 'compileSdk 36':'compileSdk = 36' in gradle,
 'targetSdk 36':'targetSdk = 36' in gradle,
 'RTL support':'android:supportsRtl="true"' in manifest,
 'status bar inset':'WindowInsets.statusBars' in src,
 'navigation inset':'navigationBarsPadding()' in src,
 'IME inset':'imePadding()' in src,
 'vertical scroll':'verticalScroll(rememberScrollState())' in src,
 'responsive compact layout':'maxWidth < 360.dp' in src,
 'no empty click handlers':'onClick = {}' not in src,
 'no TODO placeholders':'TODO' not in src,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' - '+k)
if not all(checks.values()): sys.exit(1)
