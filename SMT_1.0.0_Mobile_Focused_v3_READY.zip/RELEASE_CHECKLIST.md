# SMT Release Gate

قبل از انتشار واقعی باید این موارد روی APK/AAB واقعی و دستگاه‌های واقعی PASS شوند:
- [ ] Unit / Integration / UI tests
- [ ] Room migration + corruption recovery
- [ ] WorkManager resume / process death
- [ ] Media3 large media / decoder lifecycle
- [ ] RAM / GPU / ANR / battery
- [ ] Offline/online conflict and retry
- [ ] Backend authorization and owner entitlement
- [ ] API secrets absent from APK
- [ ] Usage/quota race and server-time reset
- [ ] Idempotency scoped by user + project incarnation
- [ ] Export atomicity and low-storage handling
- [ ] RTL / Persian shaping / ZWNJ / numerals
- [ ] Accessibility and font scaling
- [ ] Security review / exported components / deep links
- [ ] Signed release build and Play Console checks
