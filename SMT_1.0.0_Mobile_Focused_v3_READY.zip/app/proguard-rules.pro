# SMT release rules. Keep this file intentionally small; add rules only for libraries that require them.
