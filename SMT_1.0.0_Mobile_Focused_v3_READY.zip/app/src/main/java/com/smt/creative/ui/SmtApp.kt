package com.smt.creative.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.LayoutDirection

private val Bg = Color(0xFF07080A)
private val Surface = Color(0xFF111318)
private val Surface2 = Color(0xFF171A20)
private val Gold = Color(0xFFD9B56D)
private val TextPrimary = Color(0xFFF5F3ED)
private val Muted = Color(0xFF9B9DA5)

private enum class Studio(val title: String, val icon: ImageVector, val subtitle: String) {
    VIDEO("ادیت فیلم", Icons.Default.Movie, "تدوین، زیرنویس و بهبود ویدئو"),
    PHOTO("ادیت تصویر", Icons.Default.PhotoCamera, "رتوش، نور، رنگ و ارتقا"),
    AUDIO("ادیت صوت", Icons.Default.GraphicEq, "پاکسازی و صدای استودیویی"),
    DESIGN("طراحی پوستر", Icons.Default.Brush, "پوستر، لوگو و طراحی خلاقانه")
}

@Composable
fun SmtApp() {
    var studio by remember { mutableStateOf<Studio?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    var command by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf<String?>(null) }
    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(notice) {
        notice?.let { snackbarHostState.showSnackbar(it) }
        notice = null
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Surface(color = Bg, modifier = Modifier.fillMaxSize()) {
            Box(Modifier.fillMaxSize()) {
            AnimatedContent(
                targetState = when {
                    showSettings -> "settings"
                    studio != null -> "studio"
                    else -> "home"
                },
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "smt-root"
            ) { screen ->
                when (screen) {
                    "home" -> HomeScreen(command, { command = it }, { studio = it }, { showSettings = true }, { notice = it })
                    "studio" -> StudioScreen(studio!!, command, { command = it }, { studio = null }, { showSettings = true }, { notice = it })
                    else -> SettingsScreen { showSettings = false }
                }
            }
            SnackbarHost(hostState = snackbarHostState, modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(12.dp))
            }
        }
    }
}

@Composable
private fun Header(onSettings: () -> Unit, onNotice: (String) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.statusBars)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(15.dp))
                .background(Brush.linearGradient(listOf(Gold, Color(0xFF806A42)))),
            contentAlignment = Alignment.Center
        ) {
            Text("SMT", color = Color(0xFF090A0C), fontWeight = FontWeight.Black, fontSize = 13.sp)
        }
        Spacer(Modifier.weight(1f))
        IconButton(onClick = { onNotice("فرمان صوتی در نسخه کامل فعال می‌شود") }, modifier = Modifier.size(44.dp)) { Icon(Icons.Default.Mic, "فرمان صوتی", tint = TextPrimary) }
        IconButton(onClick = { onNotice("مرکز اعلان‌ها آماده اتصال به Jobهاست") }, modifier = Modifier.size(44.dp)) { Icon(Icons.Default.NotificationsNone, "اعلان‌ها", tint = TextPrimary) }
        IconButton(onClick = onSettings, modifier = Modifier.size(44.dp)) { Icon(Icons.Default.Settings, "تنظیمات", tint = TextPrimary) }
    }
}

@Composable
private fun HomeScreen(command: String, onCommand: (String) -> Unit, openStudio: (Studio) -> Unit, settings: () -> Unit, notice: (String) -> Unit) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val compact = maxWidth < 360.dp
        val horizontal = if (compact) 14.dp else 18.dp

        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .imePadding()
                .navigationBarsPadding()
        ) {
            Header(settings, notice)
            Column(Modifier.padding(horizontal = horizontal)) {
                Spacer(Modifier.height(if (compact) 18.dp else 28.dp))
                Text(
                    "چی می‌خوای بسازی؟",
                    color = TextPrimary,
                    fontSize = if (compact) 27.sp else 30.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Right
                )
                Text(
                    "SMT — AI Creative Studio",
                    color = Muted,
                    fontSize = 13.sp,
                    modifier = Modifier.fillMaxWidth().padding(top = 7.dp),
                    textAlign = TextAlign.Right
                )
                Spacer(Modifier.height(18.dp))
                CommandBar(command, onCommand)
                Spacer(Modifier.height(22.dp))
                StudioGrid(compact, openStudio)
                Spacer(Modifier.height(18.dp))
                Text(
                    "✨ قدرت حرفه‌ای در پشت صحنه، سادگی در جلوی کاربر",
                    color = Muted,
                    fontSize = 11.sp,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun StudioGrid(compact: Boolean, openStudio: (Studio) -> Unit) {
    val entries = Studio.entries
    if (compact) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            entries.forEach { StudioCard(it, { openStudio(it) }, compact) }
        }
    } else {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            entries.chunked(2).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEach { StudioCard(it, { openStudio(it) }, false, Modifier.weight(1f)) }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun CommandBar(value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp),
        singleLine = true,
        maxLines = 1,
        placeholder = { Text("به SMT بگو چی می‌خوای", color = Muted, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        leadingIcon = { Icon(Icons.Default.AutoAwesome, null, tint = Gold) },
        shape = RoundedCornerShape(18.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Gold,
            unfocusedBorderColor = Color(0xFF2A2D34),
            focusedContainerColor = Surface,
            unfocusedContainerColor = Surface,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary
        )
    )
}

@Composable
private fun StudioCard(studio: Studio, onClick: () -> Unit, compact: Boolean, modifier: Modifier = Modifier) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(if (compact) 20.dp else 22.dp),
        colors = CardDefaults.cardColors(containerColor = Surface),
        modifier = modifier.fillMaxWidth().height(if (compact) 116.dp else 158.dp)
    ) {
        Row(
            Modifier.fillMaxSize().padding(if (compact) 15.dp else 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(if (compact) 46.dp else 50.dp).clip(RoundedCornerShape(15.dp)).background(Surface2),
                contentAlignment = Alignment.Center
            ) { Icon(studio.icon, null, tint = Gold, modifier = Modifier.size(25.dp)) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(studio.title, color = TextPrimary, fontSize = if (compact) 16.sp else 17.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(studio.subtitle, color = Muted, fontSize = 10.sp, lineHeight = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 5.dp))
            }
        }
    }
}

@Composable
private fun StudioScreen(studio: Studio, command: String, onCommand: (String) -> Unit, back: () -> Unit, settings: () -> Unit, notice: (String) -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).imePadding().navigationBarsPadding()
    ) {
        Header(settings)
        Column(Modifier.padding(horizontal = 18.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = back) { Icon(Icons.Default.ArrowForward, "بازگشت", tint = TextPrimary) }
                Column(Modifier.weight(1f)) {
                    Text(studio.title, color = TextPrimary, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(studio.subtitle, color = Muted, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
                Icon(studio.icon, null, tint = Gold, modifier = Modifier.size(30.dp))
            }
            Spacer(Modifier.height(18.dp))
            CommandBar(command, onCommand)
            Spacer(Modifier.height(14.dp))
            Button(onClick = { notice("دستور ثبت شد؛ موتور AI Director در نسخه کامل اجرا می‌شود") }, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(17.dp), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF08090A))) {
                Icon(Icons.Default.AutoAwesome, null)
                Spacer(Modifier.width(7.dp))
                Text("خودت حرفه‌ای‌ش کن", fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(20.dp))
            SectionTitle("ورودی پروژه را انتخاب کن")
            HorizontalChipRow(listOf("فایل‌ها", "دوربین", "گالری"), notice)
            Spacer(Modifier.height(20.dp))
            SectionTitle("کیفیت پردازش")
            HorizontalChipRow(listOf("⚡ سریع", "⚖️ متعادل", "💎 حداکثر کیفیت", "🧠 خودکار"), notice)
            Spacer(Modifier.height(24.dp))
            Surface(color = Surface, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Text("در نسخه کامل، SMT بر اساس دستور تو بهترین مسیر پردازش را خودش انتخاب می‌کند.", color = Muted, fontSize = 11.sp, lineHeight = 18.sp, modifier = Modifier.padding(15.dp), textAlign = TextAlign.Right)
            }
            Spacer(Modifier.height(18.dp))
        }
    }
}

@Composable private fun SectionTitle(text: String) { Text(text, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Right) }

@Composable
private fun HorizontalChipRow(labels: List<String>, notice: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
        labels.forEach { ActionChip(it) { notice("«$it» انتخاب شد") } }
    }
}

@Composable private fun ActionChip(label: String, onClick: () -> Unit) {
    Surface(shape = RoundedCornerShape(14.dp), color = Surface2, modifier = Modifier.clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick)) {
        Text(label, color = TextPrimary, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 13.dp, vertical = 10.dp), maxLines = 1)
    }
}

@Composable
private fun SettingsScreen(back: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().windowInsetsPadding(WindowInsets.statusBars).padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = back) { Icon(Icons.Default.ArrowForward, "بازگشت", tint = TextPrimary) }
            Text("تنظیمات", color = TextPrimary, fontSize = 25.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.Right)
        }
        Column(Modifier.padding(horizontal = 18.dp)) {
            SettingsRow("ظاهر و تم", "Obsidian · تیره لوکس", Icons.Default.Palette)
            SettingsRow("زبان", "فارسی", Icons.Default.Language)
            SettingsRow("حریم خصوصی", "کنترل داده‌ها و مجوزها", Icons.Default.Lock)
            SettingsRow("دانلودها", "فونت، قالب و منابع", Icons.Default.Download)
            SettingsRow("درباره SMT", "© 2026 SMT · سید محمد طاها علوی و سید محمد حسین حسن‌زاده", Icons.Default.Info)
        }
    }
}

@Composable private fun SettingsRow(title: String, subtitle: String, icon: ImageVector) {
    Row(Modifier.fillMaxWidth().padding(vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Gold, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(13.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = TextPrimary, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(subtitle, color = Muted, fontSize = 10.sp, lineHeight = 15.sp, modifier = Modifier.padding(top = 4.dp), maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}
