package com.smt.creative.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Dark = darkColorScheme(primary = Color(0xFFD9B56D), onPrimary = Color(0xFF101010), background = Color(0xFF07080A), surface = Color(0xFF111318), onBackground = Color(0xFFF5F3ED), onSurface = Color(0xFFF5F3ED))

@Composable fun SmtTheme(content: @Composable () -> Unit) { MaterialTheme(colorScheme = Dark, content = content) }
